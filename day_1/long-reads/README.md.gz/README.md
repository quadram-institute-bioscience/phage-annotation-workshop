
```bash
seqfu cat --min-len 50000 --prefix seq --add-len --fasta --strip-name --strip-comment /data/reads/ont/T7-ONT.fastq.gz  > longread.fa
```


